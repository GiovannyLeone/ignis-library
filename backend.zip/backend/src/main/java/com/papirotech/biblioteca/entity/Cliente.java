package com.papirotech.biblioteca.entity;

import com.papirotech.biblioteca.enums.StatusCliente;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.Collection;
import java.util.List;

/**
 * Classe Cliente — herda de Pessoa. Mapeada em tb_usuario (JOINED com tb_pessoa).
 *
 * Atributos conforme diagrama (seção 3.4):
 *   - historico : List<Emprestimo>
 *   - favoritos : List<Livro>  (tb_favorito)
 *   - status : Enum(ATIVO, BLOQUEADO)  → FK → tb_status_usuario
 *
 * Métodos conforme diagrama:
 *   + getHistorico() : List<Emprestimo>
 *   + getFavoritos() : List<Livro>
 *   + getStatus() : Enum
 *   + setStatus(status: Enum) : void
 *   + consultarHistorico() : List<Emprestimo>
 *   + verificarStatus() : boolean
 *   + gerarCodigoEmprestimo(livro, cliente) : Emprestimo
 *   + gerarCodigoDevolucao(emprestimo) : String
 *   + favoritarLivro(livro) : void
 */
@Entity
@Table(name = "tb_usuario")
@PrimaryKeyJoinColumn(name = "id_usuario")
@Getter
@Setter
@NoArgsConstructor
public class Cliente extends Pessoa {

    // ===== Métodos de negócio conforme diagrama =====


    public boolean verificarStatus() {
        return status != null && StatusCliente.ATIVO.equals(status.getDescricao());
    }

    // gerarCodigoEmprestimo, gerarCodigoDevolucao e favoritarLivro
    // implementados no EmprestimoService e FavoritoService

    // ===== Spring Security =====

    @Override
    public boolean isAccountNonLocked() {
        return verificarStatus();
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_CLIENTE"));
    }
}
